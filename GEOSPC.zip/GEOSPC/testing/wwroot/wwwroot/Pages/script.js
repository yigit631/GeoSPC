﻿document.addEventListener('DOMContentLoaded', () => {
    // 1) Önce haritayı başlat, böylece hiç boş kalmaz
    const map = L.map('map').setView([39.0, 35.0], 6);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);

    // 2) Veriyi fetch et
    const stationsUrl = 'stations.json';
    const monthlyUrl = 'Aylik_Ortalama.json'; // doğru dosya adı

    function fetchJson(url) {
        return fetch(url)
            .then(res => {
                if (!res.ok) throw new Error(`${url} yüklenemedi: ${res.status}`);
                return res.json();
            });
    }

    Promise.all([
        fetchJson(stationsUrl),
        fetchJson(monthlyUrl)
    ])
        .then(([stations, data]) => {
            console.log('Veriler yüklendi:', stations.length, 'istasyon,', data.length, 'kayıt');

            // 3) Yıllık istatistikleri hazırla
            const stats = {};
            data.forEach(d => {
                const id = d.Istasyon_No;
                const year = +d.YIL;
                const tmp = +d.ORTALAMA_SICAKLIK;
                if (year < 2005 || year > 2024) return;
                if (!stats[id]) stats[id] = { sumByYear: {}, countByYear: {} };
                stats[id].sumByYear[year] = (stats[id].sumByYear[year] || 0) + tmp;
                stats[id].countByYear[year] = (stats[id].countByYear[year] || 0) + 1;
            });
            Object.values(stats).forEach(obj => {
                obj.years = [];
                obj.yearlyAvg = [];
                for (let y = 2005; y <= 2024; y++) {
                    obj.years.push(y);
                    if (obj.countByYear[y]) {
                        obj.yearlyAvg.push(+(obj.sumByYear[y] / obj.countByYear[y]).toFixed(2));
                    } else {
                        obj.yearlyAvg.push(0);
                    }
                }
            });

            // 4) Marker ve X-Bar popup
            stations.forEach(st => {
                const marker = L.marker([st.lat, st.lon]).addTo(map);
                marker.bindPopup(`
        <div class="popup-container">
          <h4>${st.Istasyon_Adi}</h4>
          <small style="display:block;text-align:center;margin:6px 0;">X-Bar Chart</small>
          <canvas id="chart-${st.Istasyon_No}"></canvas>
        </div>
      `);
                marker.on('popupopen', () => {
                    const ctx = document.getElementById(`chart-${st.Istasyon_No}`).getContext('2d');
                    if (ctx._chart) return;

                    const s = stats[st.Istasyon_No];
                    const labels = s.years;
                    const avg = s.yearlyAvg;
                    const mean = avg.reduce((a, b) => a + b, 0) / avg.length;
                    const sigma = Math.sqrt(avg.map(v => Math.pow(v - mean, 2)).reduce((a, b) => a + b, 0) / avg.length);
                    const UCL = Array(labels.length).fill(+(mean + 2 * sigma).toFixed(2));
                    const LCL = Array(labels.length).fill(+(mean - 2 * sigma).toFixed(2));

                    ctx._chart = new Chart(ctx, {
                        type: 'line',
                        data: {
                            labels,
                            datasets: [
                                { label: 'UCL', data: UCL, borderColor: '#aaa', borderDash: [6, 4], pointRadius: 0, fill: false },
                                { label: 'Average', data: avg, borderColor: '#ff7f50', borderWidth: 2, tension: 0.4, pointRadius: 4, pointBackgroundColor: '#ff7f50', fill: false },
                                { label: 'LCL', data: LCL, borderColor: '#aaa', borderDash: [6, 4], pointRadius: 0, fill: false }
                            ]
                        },
                        options: {
                            maintainAspectRatio: false,
                            layout: { padding: 8 },
                            plugins: {
                                legend: { display: true, position: 'bottom', labels: { color: '#fff', boxWidth: 12, padding: 8 } },
                                tooltip: { callbacks: { label(ctx) { return `${ctx.dataset.label}: ${ctx.parsed.y} °C`; } } }
                            },
                            scales: {
                                x: { title: { display: true, text: 'Yıl', color: '#ddd' }, ticks: { color: '#ddd' }, grid: { display: false } },
                                y: { title: { display: true, text: '°C', color: '#ddd' }, ticks: { color: '#ddd' }, grid: { color: 'rgba(255,255,255,0.1)' } }
                            }
                        }
                    });
                });
            });
        })
        .catch(err => {
            console.error('Veri yükleme hatası:', err);
            // fetch hatası map’i etkilemez, en azından arka plan harita gözükür
        });
});
