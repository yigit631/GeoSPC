import unittest
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class GeoSPCTestSuite(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.driver = webdriver.Chrome()  # Tarayıcıyı başlat
        cls.driver.maximize_window()     # Tam ekran yap
        cls.base_url = "http://127.0.0.1:5500"  # Localhost yolunu belirle

    @classmethod
    def tearDownClass(cls):
        cls.driver.quit()  # Testler bitince tarayıcıyı kapat

    def test_01_homepage_title(self):
        self.driver.get(f"{self.base_url}/Homepage.html")  # Anasayfayı aç
        WebDriverWait(self.driver, 5).until(EC.title_contains("Geo SPC"))  # Başlığın "Geo SPC" içermesini bekle
        title = self.driver.title  # Başlığı al
        self.assertIn("Geo SPC", title, "Ana sayfa başlığı beklenildiği gibi değil.")  # Başlıkta "Geo SPC" var mı kontrol et

    def test_02_navigate_to_about_page(self):
        self.driver.get(f"{self.base_url}/Homepage.html")  # Anasayfayı aç
        WebDriverWait(self.driver, 5).until(EC.presence_of_element_located((By.TAG_NAME, "body")))  # Sayfanın yüklendiğinden emin ol  (Expected Condition)

        try:
            about_link = self.driver.find_element(By.LINK_TEXT, "About")  # About linkini bul
        except:
            about_link = None  # Bulamazsan None yap

        if about_link:
            about_link.click()  # Varsa tıkla
        else:
            self.driver.get(f"{self.base_url}/AboutPage.html")  # Yoksa sayfaya doğrudan git

        h1 = WebDriverWait(self.driver, 5).until(
            EC.visibility_of_element_located((By.TAG_NAME, "h1"))  # h1 başlığını bekle
        )
        self.assertEqual(h1.text.strip(), "About This Project", "About sayfasındaki başlık beklenildiği gibi değil.")  # Başlığı kontrol et






        

    def test_03_navigate_to_how_it_works_and_chart(self):
        self.driver.get(f"{self.base_url}/HowItWorksPage.html")  # Sayfayı aç
        WebDriverWait(self.driver, 5).until(EC.presence_of_element_located((By.TAG_NAME, "body")))  # Sayfanın geldiğinden emin ol

        try:
            example_img = WebDriverWait(self.driver, 5).until(
                EC.presence_of_element_located((By.ID, "exampleChart"))  # Görseli bul
            )
            src_attr = example_img.get_attribute("src")  # Görselin src bilgisini al
            self.assertIn("ExampleChart.png", src_attr, "Grafik görselinin kaynağı beklenen değil.")  # src içinde dosya adı var mı bak

            
        except Exception as e:
            self.fail(f"Grafik görseli bulunamadı veya yüklenmedi: {e}")  # Hata varsa testi başarısız yap

    def test_04_navigate_to_contact_and_submit_form(self):
        self.driver.get(f"{self.base_url}/ContactPage.html")  # İletişim sayfasını aç
        WebDriverWait(self.driver, 5).until(EC.presence_of_element_located((By.TAG_NAME, "form")))  # Form yüklensin

        # Input alanlarını seç
        name_input = self.driver.find_element(By.ID, "name")
        surname_input = self.driver.find_element(By.ID, "surname")
        email_input = self.driver.find_element(By.ID, "email")
        phone_input = self.driver.find_element(By.ID, "phoneNumber")
        message_input = self.driver.find_element(By.ID, "message")
        submit_button = self.driver.find_element(By.CSS_SELECTOR, "button[type='submit']")

        # Alanları temizle ve test verilerini gir
        name_input.clear()
        name_input.send_keys("Yiğit")
        surname_input.clear()
        surname_input.send_keys("Örnek")
        email_input.clear()
        email_input.send_keys("yigit@example.com")
        phone_input.clear()
        phone_input.send_keys("0555 123 45 67")
        message_input.clear()
        message_input.send_keys("Bu bir test mesajıdır.")

        submit_button.click()  # Formu gönder
        

        WebDriverWait(self.driver, 5).until(
            lambda drv: name_input.get_attribute("value") == ""  # Name input boşalıncaya kadar bekle
        )

        # Form gönderimi sonrası alanların boş olduğunu kontrol et
        self.assertEqual(name_input.get_attribute("value"), "", "Gönderim sonrası Name alanı boş değil.")
        self.assertEqual(surname_input.get_attribute("value"), "", "Gönderim sonrası Surname alanı boş değil.")
        self.assertEqual(email_input.get_attribute("value"), "", "Gönderim sonrası Email alanı boş değil.")

    def test_05_homepage_map_popup_opens_chart(self):
        self.driver.get(f"{self.base_url}/index.html")  # Harita sayfasını aç

        WebDriverWait(self.driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, ".leaflet-marker-icon"))  # Marker ikonunun gelmesini bekle
        )

        first_marker = self.driver.find_element(By.CSS_SELECTOR, ".leaflet-marker-icon")  # Marker'ı seç
        first_marker.click()  # Marker'a tıkla

        popup_canvas = WebDriverWait(self.driver, 5).until(
            EC.visibility_of_element_located((By.CSS_SELECTOR, "canvas[id^='chart-']"))  # Popup içindeki grafik gelene kadar bekle
        )

        self.assertTrue(popup_canvas.is_displayed(), "Popup’taki grafik canvas elemanı gösterimde değil.")  # Grafik görünüyor mu kontrol et





    
if __name__ == "__main__":

    unittest.main(verbosity=2)  # Test sonuçlarını detaylı göster
