﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace MapApp2.Migrations
{
    /// <inheritdoc />
    public partial class Init : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "YearlyDatas");

            migrationBuilder.DropTable(
                name: "Batch");

            migrationBuilder.DropTable(
                name: "MonthlyDatas");

            migrationBuilder.DropTable(
                name: "Points");

            migrationBuilder.DropColumn(
                name: "AY",
                table: "TemporImports");

            migrationBuilder.RenameColumn(
                name: "YIL",
                table: "TemporImports",
                newName: "Rakim");

            migrationBuilder.RenameColumn(
                name: "ORTALAMA_SICAKLIK",
                table: "TemporImports",
                newName: "Enlem");

            migrationBuilder.AlterDatabase()
                .OldAnnotation("Npgsql:PostgresExtension:postgis", ",,");

            migrationBuilder.AlterColumn<string>(
                name: "Istasyon_Adi",
                table: "TemporImports",
                type: "character varying(100)",
                maxLength: 100,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "text");

            migrationBuilder.AddColumn<double>(
                name: "Boylam",
                table: "TemporImports",
                type: "double precision",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<string>(
                name: "Ilce",
                table: "TemporImports",
                type: "character varying(100)",
                maxLength: 100,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Sehir",
                table: "TemporImports",
                type: "character varying(100)",
                maxLength: 100,
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateTable(
                name: "TemporImport",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Istasyon_No = table.Column<int>(type: "integer", nullable: false),
                    Istasyon_Adi = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
                    YIL = table.Column<int>(type: "integer", nullable: false),
                    AY = table.Column<int>(type: "integer", nullable: false),
                    ORTALAMA_SICAKLIK = table.Column<double>(type: "double precision", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TemporImport", x => x.Id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "TemporImport");

            migrationBuilder.DropColumn(
                name: "Boylam",
                table: "TemporImports");

            migrationBuilder.DropColumn(
                name: "Ilce",
                table: "TemporImports");

            migrationBuilder.DropColumn(
                name: "Sehir",
                table: "TemporImports");

            migrationBuilder.RenameColumn(
                name: "Rakim",
                table: "TemporImports",
                newName: "YIL");

            migrationBuilder.RenameColumn(
                name: "Enlem",
                table: "TemporImports",
                newName: "ORTALAMA_SICAKLIK");

            migrationBuilder.AlterDatabase()
                .Annotation("Npgsql:PostgresExtension:postgis", ",,");

            migrationBuilder.AlterColumn<string>(
                name: "Istasyon_Adi",
                table: "TemporImports",
                type: "text",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "character varying(100)",
                oldMaxLength: 100);

            migrationBuilder.AddColumn<int>(
                name: "AY",
                table: "TemporImports",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "Points",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    IstasyonNo = table.Column<int>(type: "integer", nullable: false),
                    Name = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: true),
                    X = table.Column<double>(type: "double precision", nullable: false),
                    Y = table.Column<double>(type: "double precision", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Points", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "MonthlyDatas",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    PointId = table.Column<int>(type: "integer", nullable: false),
                    Temp = table.Column<float>(type: "real", nullable: false),
                    month = table.Column<float>(type: "real", nullable: false),
                    year = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MonthlyDatas", x => x.Id);
                    table.ForeignKey(
                        name: "FK_MonthlyDatas_Points_PointId",
                        column: x => x.PointId,
                        principalTable: "Points",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Batch",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    MonthlyDataId = table.Column<int>(type: "integer", nullable: false),
                    PointId = table.Column<int>(type: "integer", nullable: false),
                    Date = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    LCL = table.Column<float>(type: "real", nullable: false),
                    Mean = table.Column<float>(type: "real", nullable: false),
                    UCL = table.Column<float>(type: "real", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Batch", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Batch_MonthlyDatas_MonthlyDataId",
                        column: x => x.MonthlyDataId,
                        principalTable: "MonthlyDatas",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Batch_Points_PointId",
                        column: x => x.PointId,
                        principalTable: "Points",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "YearlyDatas",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    BatchId = table.Column<int>(type: "integer", nullable: true),
                    PointId = table.Column<int>(type: "integer", nullable: false),
                    Date = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    Temp = table.Column<float>(type: "real", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_YearlyDatas", x => x.Id);
                    table.ForeignKey(
                        name: "FK_YearlyDatas_Batch_BatchId",
                        column: x => x.BatchId,
                        principalTable: "Batch",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_YearlyDatas_Points_PointId",
                        column: x => x.PointId,
                        principalTable: "Points",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Batch_MonthlyDataId",
                table: "Batch",
                column: "MonthlyDataId");

            migrationBuilder.CreateIndex(
                name: "IX_Batch_PointId",
                table: "Batch",
                column: "PointId");

            migrationBuilder.CreateIndex(
                name: "IX_MonthlyDatas_PointId",
                table: "MonthlyDatas",
                column: "PointId");

            migrationBuilder.CreateIndex(
                name: "IX_YearlyDatas_BatchId",
                table: "YearlyDatas",
                column: "BatchId");

            migrationBuilder.CreateIndex(
                name: "IX_YearlyDatas_PointId",
                table: "YearlyDatas",
                column: "PointId");
        }
    }
}
