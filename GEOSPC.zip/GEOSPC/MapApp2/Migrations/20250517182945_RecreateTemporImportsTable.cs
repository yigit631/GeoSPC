﻿using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace MapApp2.Migrations
{
    /// <inheritdoc />
    public partial class RecreateTemporImportsTable : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_TemporImports",
                table: "TemporImports");

            migrationBuilder.DropPrimaryKey(
                name: "PK_TemporImport",
                table: "TemporImport");

            migrationBuilder.DropColumn(
                name: "Id",
                table: "TemporImports");

            migrationBuilder.DropColumn(
                name: "Sehir",
                table: "TemporImports");

            migrationBuilder.DropColumn(
                name: "Id",
                table: "TemporImport");

            migrationBuilder.AlterColumn<double>(
                name: "Rakim",
                table: "TemporImports",
                type: "double precision",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "integer");

            migrationBuilder.AlterColumn<int>(
                name: "Istasyon_No",
                table: "TemporImports",
                type: "integer",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "integer")
                .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AlterColumn<string>(
                name: "Istasyon_Adi",
                table: "TemporImports",
                type: "varchar(100)",
                maxLength: 100,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "character varying(100)",
                oldMaxLength: 100);

            migrationBuilder.AlterColumn<string>(
                name: "Ilce",
                table: "TemporImports",
                type: "varchar(100)",
                maxLength: 100,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "character varying(100)",
                oldMaxLength: 100);

            migrationBuilder.AddColumn<string>(
                name: "Il",
                table: "TemporImports",
                type: "varchar(100)",
                maxLength: 100,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AlterColumn<string>(
                name: "Istasyon_Adi",
                table: "TemporImport",
                type: "varchar(100)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "character varying(100)",
                oldMaxLength: 100);

            migrationBuilder.AddPrimaryKey(
                name: "PK_TemporImports",
                table: "TemporImports",
                column: "Istasyon_No");

            migrationBuilder.AddPrimaryKey(
                name: "PK_TemporImport",
                table: "TemporImport",
                columns: new[] { "Istasyon_No", "YIL", "AY" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_TemporImports",
                table: "TemporImports");

            migrationBuilder.DropPrimaryKey(
                name: "PK_TemporImport",
                table: "TemporImport");

            migrationBuilder.DropColumn(
                name: "Il",
                table: "TemporImports");

            migrationBuilder.AlterColumn<int>(
                name: "Rakim",
                table: "TemporImports",
                type: "integer",
                nullable: false,
                oldClrType: typeof(double),
                oldType: "double precision");

            migrationBuilder.AlterColumn<string>(
                name: "Istasyon_Adi",
                table: "TemporImports",
                type: "character varying(100)",
                maxLength: 100,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "varchar(100)",
                oldMaxLength: 100);

            migrationBuilder.AlterColumn<string>(
                name: "Ilce",
                table: "TemporImports",
                type: "character varying(100)",
                maxLength: 100,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "varchar(100)",
                oldMaxLength: 100);

            migrationBuilder.AlterColumn<int>(
                name: "Istasyon_No",
                table: "TemporImports",
                type: "integer",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "integer")
                .OldAnnotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AddColumn<int>(
                name: "Id",
                table: "TemporImports",
                type: "integer",
                nullable: false,
                defaultValue: 0)
                .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AddColumn<string>(
                name: "Sehir",
                table: "TemporImports",
                type: "character varying(100)",
                maxLength: 100,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AlterColumn<string>(
                name: "Istasyon_Adi",
                table: "TemporImport",
                type: "character varying(100)",
                maxLength: 100,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "varchar(100)");

            migrationBuilder.AddColumn<int>(
                name: "Id",
                table: "TemporImport",
                type: "integer",
                nullable: false,
                defaultValue: 0)
                .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AddPrimaryKey(
                name: "PK_TemporImports",
                table: "TemporImports",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_TemporImport",
                table: "TemporImport",
                column: "Id");
        }
    }
}
