﻿using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace MapApp2.Migrations
{
    /// <inheritdoc />
    public partial class SpatialFix : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // Removed PostGIS extension annotation to avoid unsupported extension error

            migrationBuilder.AlterColumn<string>(
                name: "Name",
                table: "Points",
                type: "character varying(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "text",
                oldNullable: true);

            migrationBuilder.AddColumn<int>(
                name: "IstasyonNo",
                table: "Points",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "TemporImports",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Istasyon_No = table.Column<int>(type: "integer", nullable: false),
                    Istasyon_Adi = table.Column<string>(type: "text", nullable: false),
                    YIL = table.Column<int>(type: "integer", nullable: false),
                    AY = table.Column<int>(type: "integer", nullable: false),
                    ORTALAMA_SICAKLIK = table.Column<double>(type: "double precision", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TemporImports", x => x.Id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "TemporImports");

            migrationBuilder.DropColumn(
                name: "IstasyonNo",
                table: "Points");

            migrationBuilder.AlterColumn<string>(
                name: "Name",
                table: "Points",
                type: "text",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "character varying(100)",
                oldMaxLength: 100,
                oldNullable: true);
        }
    }
}
