﻿namespace MapApp2.Models
{
    public class AnnualTemperatureResponse
    {
        public int PointId { get; set; }
        public string IstasyonAdi { get; set; } = string.Empty;
        public double XCoord { get; set; }
        public double YCoord { get; set; }
        public List<int> Years { get; set; } = new();
        public List<double> Averages { get; set; } = new();
    }
}