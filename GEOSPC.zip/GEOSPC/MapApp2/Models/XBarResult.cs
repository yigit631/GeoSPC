﻿namespace MapApp2.Models
{
    public class XBarResult
    {
        public double Mean { get; set; }
        public double UCL { get; set; }
        public double LCL { get; set; }
        public int Count { get; set; }
    }
}