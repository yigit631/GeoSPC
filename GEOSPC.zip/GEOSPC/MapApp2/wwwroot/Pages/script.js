﻿document.addEventListener('DOMContentLoaded', function () {
    // Zoom plugin'i kaydet
    Chart.register(ChartZoom);

    // 1) Haritayı başlat
    var map = L.map('map').setView([39.0, 35.0], 6);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);

    // 2) JSON yükleme fonksiyonu
    function fetchJson(url) {
        return fetch(url).then(function (res) {
            if (!res.ok) throw new Error(url + ' yüklenemedi: ' + res.status);
            return res.json();
        });
    }

    // 3) Verileri al
    Promise.all([
        fetchJson('stations.json'),
        fetchJson('Aylik_Ortalama.json')
    ])
        .then(function (results) {
            var stations = results[0],
                data = results[1],
                stats = {};

            // 4) Yıllık özetleri hazırla
            data.forEach(function (d) {
                var id = d.Istasyon_No,
                    year = +d.YIL,
                    tmp = +d.ORTALAMA_SICAKLIK;
                if (year < 2005 || year > 2024) return;
                if (!stats[id]) {
                    stats[id] = {
                        sumByYear: {}, countByYear: {},
                        minByYear: {}, maxByYear: {}
                    };
                }
                stats[id].sumByYear[year] = (stats[id].sumByYear[year] || 0) + tmp;
                stats[id].countByYear[year] = (stats[id].countByYear[year] || 0) + 1;
                stats[id].minByYear[year] = stats[id].minByYear[year] !== undefined
                    ? Math.min(stats[id].minByYear[year], tmp)
                    : tmp;
                stats[id].maxByYear[year] = stats[id].maxByYear[year] !== undefined
                    ? Math.max(stats[id].maxByYear[year], tmp)
                    : tmp;
            });

            // 5) X̅ ve R dizileri
            Object.keys(stats).forEach(function (id) {
                var o = stats[id];
                o.years = [];
                o.yearlyAvg = [];
                o.yearlyRange = [];
                for (var y = 2005; y <= 2024; y++) {
                    o.years.push(y);
                    if (o.countByYear[y]) {
                        o.yearlyAvg.push(+(o.sumByYear[y] / o.countByYear[y]).toFixed(2));
                        o.yearlyRange.push(+(o.maxByYear[y] - o.minByYear[y]).toFixed(2));
                    } else {
                        o.yearlyAvg.push(0);
                        o.yearlyRange.push(0);
                    }
                }
            });

            // 6) Marker & Popup
            stations.forEach(function (st) {
                var marker = L.marker([st.lat, st.lon]).addTo(map);
                var popupHtml = ''
                    + '<div class="popup-container">'
                    + '<h4>' + st.Istasyon_Adi + '</h4>'
                    + '<div class="chart-buttons">'
                    + '<button class="chart-btn" id="xbtn-' + st.Istasyon_No + '">X-Bar</button>'
                    + '<button class="chart-btn" id="rbtn-' + st.Istasyon_No + '">R Chart</button>'
                    + '</div>'
                    + '<div class="chart-wrapper">'
                    + '<canvas id="xchart-' + st.Istasyon_No + '" class="chart-canvas" style="left:0;"></canvas>'
                    + '<canvas id="rchart-' + st.Istasyon_No + '" class="chart-canvas" style="left:100%;"></canvas>'
                    + '</div>'
                    + '</div>';
                marker.bindPopup(popupHtml);

                marker.on('popupopen', function () {
                    var s = stats[st.Istasyon_No],
                        labels = s.years;

                    // --- X-Bar Chart ---
                    (function () {
                        var ctxX = document.getElementById('xchart-' + st.Istasyon_No).getContext('2d');
                        if (ctxX._chart) return;
                        var avg = s.yearlyAvg;
                        var meanX = avg.reduce((a, b) => a + b, 0) / avg.length;
                        var sigmaX = Math.sqrt(avg.map(v => (v - meanX) ** 2).reduce((a, b) => a + b, 0) / avg.length);
                        var UCLx = labels.map(() => +(meanX + 2 * sigmaX).toFixed(2));
                        var LCLx = labels.map(() => +(meanX - 2 * sigmaX).toFixed(2));
                        var CLx = labels.map(() => +meanX.toFixed(2));

                        ctxX._chart = new Chart(ctxX, {
                            type: 'line',
                            data: {
                                labels: labels,
                                datasets: [
                                    { label: 'UCL', data: UCLx, borderColor: '#aaa', borderDash: [6, 4], pointRadius: 0 },
                                    { label: 'Center', data: CLx, borderColor: '#fff', borderDash: [4, 4], pointRadius: 0 },
                                    { label: 'X̅', data: avg, borderColor: '#ff7f50', borderWidth: 2, tension: 0.4, pointRadius: 4, pointBackgroundColor: '#ff7f50' },
                                    { label: 'LCL', data: LCLx, borderColor: '#aaa', borderDash: [6, 4], pointRadius: 0 }
                                ]
                            },
                            options: {
                                maintainAspectRatio: false,
                                plugins: {
                                    zoom: {
                                        pan: { enabled: true, mode: 'x' },
                                        zoom: { wheel: { enabled: true }, pinch: { enabled: true }, mode: 'x' }
                                    },
                                    legend: { display: true, position: 'bottom', labels: { color: '#fff' } },
                                    tooltip: { callbacks: { label: function (ctx) { return ctx.dataset.label + ': ' + ctx.parsed.y + ' °C'; } } }
                                },
                                scales: {
                                    x: { title: { display: true, text: 'Yıl', color: '#ddd' }, ticks: { color: '#ddd' } },
                                    y: { title: { display: true, text: '°C', color: '#ddd' }, ticks: { color: '#ddd' } }
                                }
                            }
                        });
                    })();

                    // --- R Chart + Rule Detection ---
                    (function () {
                        var ctxR = document.getElementById('rchart-' + st.Istasyon_No).getContext('2d');
                        if (ctxR._chart) return;

                        var ranges = s.yearlyRange;
                        var meanR = ranges.reduce((a, b) => a + b, 0) / ranges.length;
                        var sigmaR = Math.sqrt(ranges.map(v => (v - meanR) ** 2).reduce((a, b) => a + b, 0) / ranges.length);
                        var UCLr = labels.map(() => +(meanR + 2 * sigmaR).toFixed(2));
                        var LCLr = labels.map(() => +(meanR - 2 * sigmaR).toFixed(2));
                        var CLr = labels.map(() => +meanR.toFixed(2));

                        var zd = ranges.map(v => (v - meanR) / sigmaR);
                        var flagged = Array(ranges.length).fill(false);

                        zd.forEach((v, i) => { if (Math.abs(v) > 3) flagged[i] = true; });

                        for (let i = 0; i + 2 < zd.length; i++) {
                            let high = 0, low = 0;
                            for (let j = i; j < i + 3; j++) {
                                if (zd[j] > 2) high++;
                                if (zd[j] < -2) low++;
                            }
                            if (high >= 2 || low >= 2) for (let j = i; j < i + 3; j++) flagged[j] = true;
                        }

                        for (let i = 0; i + 4 < zd.length; i++) {
                            let high = 0, low = 0;
                            for (let j = i; j < i + 5; j++) {
                                if (zd[j] > 1) high++;
                                if (zd[j] < -1) low++;
                            }
                            if (high >= 4 || low >= 4) for (let j = i; j < i + 5; j++) flagged[j] = true;
                        }

                        for (let i = 0; i + 7 < zd.length; i++) {
                            let sameSign = true;
                            for (let j = i + 1; j < i + 8; j++) {
                                if ((zd[j] > 0) !== (zd[i] > 0)) sameSign = false;
                            }
                            if (sameSign) for (let j = i; j < i + 8; j++) flagged[j] = true;
                        }

                        var colors = ranges.map((_, i) => flagged[i] ? 'red' : 'green');

                        ctxR._chart = new Chart(ctxR, {
                            type: 'line',
                            data: {
                                labels: labels,
                                datasets: [
                                    { label: 'UCL (R)', data: UCLr, borderColor: '#aaa', borderDash: [6, 4], pointRadius: 0 },
                                    { label: 'Center', data: CLr, borderColor: '#fff', borderDash: [4, 4], pointRadius: 0 },
                                    {
                                        label: 'Range', data: ranges, borderColor: '#54a0ff', borderWidth: 2, tension: 0.4,
                                        pointRadius: 5, pointBackgroundColor: colors
                                    },
                                    { label: 'LCL (R)', data: LCLr, borderColor: '#aaa', borderDash: [6, 4], pointRadius: 0 }
                                ]
                            },
                            options: {
                                maintainAspectRatio: false,
                                plugins: {
                                    zoom: {
                                        pan: { enabled: true, mode: 'x' },
                                        zoom: { wheel: { enabled: true }, pinch: { enabled: true }, mode: 'x' }
                                    },
                                    legend: { display: true, position: 'bottom', labels: { color: '#fff' } },
                                    tooltip: { callbacks: { label: function (ctx) { return ctx.dataset.label + ': ' + ctx.parsed.y; } } }
                                },
                                scales: {
                                    x: { title: { display: true, text: 'Yıl', color: '#ddd' }, ticks: { color: '#ddd' } },
                                    y: { title: { display: true, text: 'Range', color: '#ddd' }, ticks: { color: '#ddd' } }
                                }
                            }
                        });
                    })();

                    // Butonlar
                    document.getElementById('xbtn-' + st.Istasyon_No).onclick = function () {
                        document.getElementById('xchart-' + st.Istasyon_No).style.left = '0';
                        document.getElementById('rchart-' + st.Istasyon_No).style.left = '100%';
                    };
                    document.getElementById('rbtn-' + st.Istasyon_No).onclick = function () {
                        document.getElementById('xchart-' + st.Istasyon_No).style.left = '-100%';
                        document.getElementById('rchart-' + st.Istasyon_No).style.left = '0';
                    };

                }); // popupopen
            });   // stations.forEach
        })        // then
        .catch(function (err) {
            console.error('Veri yükleme hatası:', err);
        });
});
