﻿// Entity sınıflarını içeri al
using MapApp2.Entity;

// Entity Framework Core işlevlerini aktif et
using Microsoft.EntityFrameworkCore;

namespace MapApp2.Data
{
    // Uygulamanın veritabanı bağlamını tanımla
    public class AppDbContext : DbContext
    {
        // Yapılandırıcı metot: dışarıdan gelen ayarlarla DbContext’i başlat
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }

        // TemporImport tablosunu temsil eden DbSet’i tanımla (Aylık sıcaklık verisi)
        public DbSet<TemporImport> TemporImports { get; set; }

        // TemporImports tablosunu temsil eden DbSet’i tanımla (İstasyon meta verisi)
        public DbSet<TemporImports> TemporImportss { get; set; }

        // Veritabanı tablolarının konfigürasyonunu yapılandır
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Taban sınıfın yapılandırmasını çağır
            base.OnModelCreating(modelBuilder);

            // Aylık sıcaklık verilerini yapılandır
            modelBuilder.Entity<TemporImport>(entity =>
            {
                // Tablo adını belirle
                entity.ToTable("TemporImport");

                // Birleşik anahtarı tanımla (İstasyon_No, YIL, AY)
                entity.HasKey(e => new { e.Istasyon_No, e.YIL, e.AY });

                // Gerekli sütunları tanımla ve zorunlu kıl
                entity.Property(e => e.Istasyon_No).IsRequired(); // İstasyon numarasını zorunlu kıl
                entity.Property(e => e.Istasyon_Adi)
                      .HasColumnType("varchar(100)") // Veritabanı tipi olarak varchar(100) kullan
                      .IsRequired(); // Zorunlu yap
                entity.Property(e => e.YIL).IsRequired(); // Yıl zorunlu
                entity.Property(e => e.AY).IsRequired(); // Ay zorunlu
                entity.Property(e => e.ORTALAMA_SICAKLIK).IsRequired(); // Ortalama sıcaklık zorunlu
            });

            // İstasyon bilgilerini (meta verileri) yapılandır
            modelBuilder.Entity<TemporImports>(entity =>
            {
                // Tablo adını belirle
                entity.ToTable("TemporImports");

                // Anahtarı tanımla
                entity.HasKey(e => e.Istasyon_No); // Sadece istasyon numarası anahtar

                // Sütunları tanımla ve gerekliyse zorunlu kıl
                entity.Property(e => e.Istasyon_No).IsRequired(); // İstasyon numarası zorunlu
                entity.Property(e => e.Istasyon_Adi)
                      .HasColumnType("varchar(100)") // varchar(100) kullan
                      .IsRequired(); // Zorunlu yap
                entity.Property(e => e.Il)
                      .HasColumnType("varchar(100)"); // İl bilgisini varchar olarak tut
                entity.Property(e => e.Ilce)
                      .HasColumnType("varchar(100)"); // İlçe bilgisini varchar olarak tut
                entity.Property(e => e.Enlem).IsRequired(); // Enlem zorunlu
                entity.Property(e => e.Boylam).IsRequired(); // Boylam zorunlu
                entity.Property(e => e.Rakim).IsRequired(); // Rakım zorunlu
            });
        }
    }
}
