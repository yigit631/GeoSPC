﻿using System.ComponentModel.DataAnnotations;

namespace MapApp2.Entity
{
    public class User
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string Password { get; set; }

        public string? Name { get; set; }

        [EmailAddress]
        public string? Email { get; set; }

        public string? Role { get; set; }
    }
}