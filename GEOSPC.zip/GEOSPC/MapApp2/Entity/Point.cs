﻿namespace MapApp2.Entity
{
    public class Point
    {
        public int Id { get; set; }              // Primary Key
        public int IstasyonNo { get; set; }      // İstasyon numarası (eşleşme için)
        public double X { get; set; }            // Koordinat X
        public double Y { get; set; }            // Koordinat Y
        public string? Name { get; set; }        // İstasyon adı
    }
}
