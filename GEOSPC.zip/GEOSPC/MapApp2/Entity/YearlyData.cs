﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MapApp2.Entity
{
    public class YearlyData
    {
        [Key]
        public int Id { get; set; }

        public float Temp { get; set; }
        public DateTime Date { get; set; }

        // Foreign Keys
        public int PointId { get; set; }
        [ForeignKey("PointId")]
        public Point Point { get; set; }

        public int? BatchId { get; set; }
        [ForeignKey("BatchId")]
        public Batch? Batch { get; set; }
    }
}