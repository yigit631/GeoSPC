﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MapApp2.Entity
{
    public class ControlChart
    {
        [Key]
        public int Id { get; set; }

        public int BatchId { get; set; }

        [ForeignKey("BatchId")]
        public Batch Batch { get; set; }
    }
}