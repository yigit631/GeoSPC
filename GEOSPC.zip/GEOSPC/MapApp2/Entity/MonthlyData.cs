﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MapApp2.Entity
{
    public class MonthlyData
    {
        [Key]
        public int Id { get; set; }

        public int PointId { get; set; }
        [ForeignKey("PointId")]

        public int year { get; set; }
        public float month { get; set; }
        public float Temp { get; set; }
        //public DateTime Date { get; set; }
        
        

        // Foreign Key
        
        public Point Point { get; set; }
    }
}