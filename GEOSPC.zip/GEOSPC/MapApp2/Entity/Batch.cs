﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MapApp2.Entity
{
    public class Batch
    {
        [Key]
        public int Id { get; set; }

        public DateTime Date { get; set; }

        public float Mean { get; set; }
        public float UCL { get; set; }
        public float LCL { get; set; }

        // Foreign Keys
        public int PointId { get; set; }
        [ForeignKey("PointId")]
        public Point Point { get; set; }

        public int MonthlyDataId { get; set; }
        [ForeignKey("MonthlyDataId")]
        public MonthlyData MonthlyData { get; set; }
    }
}