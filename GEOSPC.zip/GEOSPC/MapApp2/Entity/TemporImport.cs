﻿using NetTopologySuite.Geometries;
using System.ComponentModel.DataAnnotations.Schema;

namespace MapApp2.Entity
{
    public class TemporImport
    {
       
        public int Istasyon_No { get; set; }
        public string Istasyon_Adi { get; set; }
        public int YIL { get; set; }
        public int AY { get; set; }
        public double ORTALAMA_SICAKLIK { get; set; }


    }
}
