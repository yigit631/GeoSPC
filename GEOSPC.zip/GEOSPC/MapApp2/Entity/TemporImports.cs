﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MapApp2.Entity
{
    [Table("TemporImports")]
    public class TemporImports
    {
        [Key]
        public int Istasyon_No { get; set; }

        [Column("Istasyon_Adi"), MaxLength(100)]
        public string Istasyon_Adi { get; set; }

        [Column("Il"), MaxLength(100)]
        public string Il { get; set; }

        [Column("Ilce"), MaxLength(100)]
        public string Ilce { get; set; }

        public double Enlem { get; set; }
        public double Boylam { get; set; }
        public double Rakim { get; set; }
    }
}
