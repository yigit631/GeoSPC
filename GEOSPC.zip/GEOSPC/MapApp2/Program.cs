﻿// Gerekli namespace'leri projeye dahil et
using MapApp2.Data; // DbContext sınıfını içeri al
using MapApp2.Services; // Servis katmanını yükle
using Microsoft.EntityFrameworkCore; // EF Core işlemlerini etkinleştir
using MapApp2.Repositories; // Repository sınıflarını dahil et
using Microsoft.EntityFrameworkCore.Diagnostics; // EF uyarılarını kontrol et
using System.Text.Json; // JSON işlemleri için gerekli kütüphane
using MapApp2.Entity; // Entity modellerini ekle
using System.IO; // Dosya işlemleri için System.IO kullan

// Web uygulaması oluşturucuyu başlat
var builder = WebApplication.CreateBuilder(args);

// 1) Gerekli servisleri ekle
builder.Services.AddControllers(); // Controller desteğini aktif et
builder.Services.AddEndpointsApiExplorer(); // Endpointleri otomatik keşfet
builder.Services.AddSwaggerGen(); // Swagger ile dokümantasyonu devreye al

// 2) CORS politikasını tanımla (geliştirme ortamı için tüm izinler açık)
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
        policy.AllowAnyOrigin() // Her kaynaktan gelen isteklere izin ver
              .AllowAnyMethod() // Her türlü HTTP metoduna izin ver
              .AllowAnyHeader()); // Header sınırlaması uygulama
});

// 3) EF Core yapılandırmasını yap ve bağlantı string'ini kullanarak PostgreSQL bağlatısını ayarla
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseNpgsql(
        builder.Configuration.GetConnectionString("DefaultConnection") // appsettings.json'daki DefaultConnection'ı kullan
    )
    .ConfigureWarnings(w => w.Ignore(RelationalEventId.PendingModelChangesWarning)) // Model uyarılarını bastır
);

// 4) Gerekli servis ve repository'leri DI (Dependency Injection) konteynerine ekle
builder.Services.AddScoped<IPointService, PointService>(); // Nokta servisini scoped olarak kaydet
builder.Services.AddScoped<IUnitOfWork, UnitOfWork>(); // Unit of Work desenini kullan
builder.Services.AddSingleton<ITemperatureAnalysisService, TemperatureAnalysisService>(); // Sıcaklık analiz servisini singleton yap
builder.Services.AddScoped<ITemporImportService, TemporImportService>(); // Aylık veri servisini scoped ekle
builder.Services.AddScoped<IAnnualTemperatureService, AnnualTemperatureService>(); // Yıllık veri servisini scoped ekle

// Uygulama yapılandırmasını tamamla ve uygulamayı başlat
var app = builder.Build();

// 5) Middleware bileşenlerini sırayla uygula
if (app.Environment.IsDevelopment()) // Eğer ortam development ise...
{
    app.UseSwagger(); // Swagger servisini devreye al
    app.UseSwaggerUI(); // Swagger UI arayüzünü aktif et
}

app.UseDefaultFiles(); // index.html gibi varsayılan dosyaları otomatik göster
app.UseStaticFiles(); // wwwroot altındaki dosyaları servis et
app.UseRouting(); // Routing sistemini başlat
app.UseCors("AllowAll"); // CORS politikasını uygula
app.UseHttpsRedirection(); // HTTP isteklerini HTTPS'e yönlendir
app.UseAuthorization(); // Yetkilendirme middleware'ini aktif et

// 6) Uygulama çalışmaya başlamadan önce JSON dosyalarını oluştur
using (var scope = app.Services.CreateScope()) // Yeni bir scope oluştur
{
    var ctx = scope.ServiceProvider.GetRequiredService<AppDbContext>(); // DbContext instance'ını al

    // Veritabanındaki kayıt sayılarını logla (kontrol amaçlı)
    var countStations = await ctx.TemporImportss.CountAsync(); // İstasyon sayısı
    var countMonthly = await ctx.TemporImports.CountAsync(); // Aylık veri sayısı
    Console.WriteLine($"Stations kayıt sayısı: {countStations}");
    Console.WriteLine($"Monthly kayıt sayısı: {countMonthly}");

    // JSON formatlama seçeneklerini ayarla
    var opts = new JsonSerializerOptions
    {
        WriteIndented = true, // JSON'u okunabilir hale getir
        DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull // Null değerleri dahil etme
    };

    // 6.a) İstasyon verilerini çek, sırala ve stations.json dosyasına yaz
    var stationData = await ctx.TemporImportss
     .AsNoTracking() // Takip etme, sadece oku -> hız için önemli 
     .Select(s => new {
         s.Istasyon_No,
         s.Istasyon_Adi,
         s.Il,
         lat = s.Enlem,
         lon = s.Boylam
     })
     .OrderBy(x => x.Istasyon_No) // İstasyon numarasına göre sırala
     .ToListAsync();

    var stationPath = Path.Combine("wwwroot/CREATED/stations.json"); // Dosya yolunu oluştur
    await File.WriteAllTextAsync(stationPath, JsonSerializer.Serialize(stationData, opts)); // JSON'a çevir ve diske yaz
    Console.WriteLine($"aylık.json oluşturuldu: {stationPath}");

    // 6.b) Aylık sıcaklık verilerini çek, sırala ve Aylik_Ortalama.json dosyasına yaz
    var monthlyData = await ctx.TemporImports
        .AsNoTracking()
        .Select(t => new
        {
            t.Istasyon_No,
            t.Istasyon_Adi,
            t.YIL,
            t.AY,
            t.ORTALAMA_SICAKLIK
        })
        .OrderBy(x => x.Istasyon_No)
        .ThenBy(x => x.YIL)
        .ThenBy(x => x.AY)
        .ToListAsync();

    var monthlyPath = Path.Combine("wwwroot/CREATED/Aylik_Ortalama.json"); // Dosya yolunu oluştur
    await File.WriteAllTextAsync(monthlyPath, JsonSerializer.Serialize(monthlyData, opts)); // JSON'a çevir ve diske yaz
    Console.WriteLine($"aylık1.json oluşturuldu: {monthlyPath}");
}

// Controller endpoint'lerini aktif hale getir
app.MapControllers();

// Eğer başka bir dosya bulunamazsa index.html dosyasına yönlendir
app.MapFallbackToFile("index.html");

// Uygulamayı çalıştır
app.Run();
