﻿using System.Collections.Generic;
using System.Threading.Tasks;
using MapApp2.Models;

namespace MapApp2.Services
{
    public interface ITemperatureAnalysisService
    {
        Task<XBarResult> GenerateXBarAsync(List<double> temperatures);
    }
}