﻿using MapApp2.Entity;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MapApp2.Services
{
    public interface ITemporImportService
    {
        Task<List<TemporImport>> GetAllAsync();
        Task<List<TemporImport>> GetByPointIdAndYearAsync(int pointId, int year);
        Task<int> MatchToPointAsync(); // Eşleştirme yapan metot
        Task<int> BulkInsertAsync(List<TemporImport> data);
    }
}