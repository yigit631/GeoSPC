﻿using MapApp2.Entity;
using MapApp2.Repositories;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MapApp2.Services
{
    public class PointService : IPointService
    {
        private readonly IUnitOfWork _unitOfWork;

        public PointService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<List<Point>> GetAllPoints()
        {
            return (await _unitOfWork.Points.GetAllAsync()).ToList();
        }

        public async Task<List<Point>> GetPointsById(int id)
        {
            return (await _unitOfWork.Points.FindAsync(p => p.Id == id)).ToList();
        }

        public async Task<List<Point>> GetPointsByX(double x)
        {
            return (await _unitOfWork.Points.FindAsync(p => p.X == x)).ToList();
        }

        public async Task<List<Point>> GetPointsByY(double y)
        {
            return (await _unitOfWork.Points.FindAsync(p => p.Y == y)).ToList();
        }

        public async Task<List<Point>> GetPointsByName(string name)
        {
            return (await _unitOfWork.Points.FindAsync(p => p.Name == name)).ToList();
        }

        public async Task<List<Point>> GetPointsByIstasyonNo(int istasyonNo)
        {
            return (await _unitOfWork.Points.FindAsync(p => p.IstasyonNo == istasyonNo)).ToList();
        }

        public async Task<Point> UpdatePoint(int id, double newX, double newY, string newName, int newIstasyonNo)
        {
            var pointsToUpdate = await _unitOfWork.Points.FindAsync(p => p.Id == id);
            if (!pointsToUpdate.Any())
            {
                throw new KeyNotFoundException("No points found with the given ID.");
            }

            var pointToUpdate = pointsToUpdate.First();
            pointToUpdate.X = newX;
            pointToUpdate.Y = newY;
            pointToUpdate.Name = newName;
            pointToUpdate.IstasyonNo = newIstasyonNo;

            _unitOfWork.Points.Update(pointToUpdate);
            await _unitOfWork.CompleteAsync();

            return pointToUpdate;
        }

        public async Task<List<Point>> UpdatePointNameById(int id, string newName)
        {
            var pointsToUpdate = await _unitOfWork.Points.FindAsync(p => p.Id == id);
            if (!pointsToUpdate.Any())
            {
                throw new KeyNotFoundException("No points found with the given ID.");
            }

            foreach (var pointToUpdate in pointsToUpdate)
            {
                pointToUpdate.Name = newName;
                _unitOfWork.Points.Update(pointToUpdate);
            }

            await _unitOfWork.CompleteAsync();
            return pointsToUpdate.ToList();
        }

        public async Task<int> DeletePointById(int id)
        {
            var pointsToDelete = await _unitOfWork.Points.FindAsync(p => p.Id == id);
            if (!pointsToDelete.Any())
            {
                return 0;
            }

            _unitOfWork.Points.RemoveRange(pointsToDelete);
            return await _unitOfWork.CompleteAsync();
        }

        public async Task<Point> AddPoint(Point point)
        {
            await _unitOfWork.Points.AddAsync(point);
            await _unitOfWork.CompleteAsync();

            return point;
        }
    }
}