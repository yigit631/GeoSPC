﻿using MapApp2.Models;
using MapApp2.Repositories;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MapApp2.Services
{
    public class AnnualTemperatureService : IAnnualTemperatureService
    {
        public Task<AnnualTemperatureResponse> GetAnnualAveragesAsync(int pointId)
        {
            // Bypass: boş yanıt dön
            var emptyResponse = new AnnualTemperatureResponse
            {
                PointId = pointId,
                IstasyonAdi = null,
                XCoord = 0,
                YCoord = 0,
                Years = new List<int>(),
                Averages = new List<double>()
            };
            return Task.FromResult(emptyResponse);
        }
    }
}
