﻿using MapApp2.Entity;
using MapApp2.Repositories;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MapApp2.Services
{
    public class TemporImportService : ITemporImportService
    {
        private readonly IUnitOfWork _unitOfWork;

        public TemporImportService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public Task<List<TemporImport>> GetAllAsync()
        {
            // Bypass: boş liste döndür
            return Task.FromResult(new List<TemporImport>());
        }

        public Task<List<TemporImport>> GetByPointIdAndYearAsync(int pointId, int year)
        {
            // Bypass: boş liste döndür
            return Task.FromResult(new List<TemporImport>());
        }

        public Task<int> MatchToPointAsync()
        {
            // Bypass: sıfır güncelleme dön
            return Task.FromResult(0);
        }

        public Task<int> BulkInsertAsync(List<TemporImport> data)
        {
            // Bypass: sıfır ekleme dön
            return Task.FromResult(0);
        }
    }
}
