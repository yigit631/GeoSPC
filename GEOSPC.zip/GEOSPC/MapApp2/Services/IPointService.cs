﻿using MapApp2.Entity;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MapApp2.Services
{
    public interface IPointService
    {
        Task<List<Point>> GetAllPoints();
        Task<List<Point>> GetPointsById(int id);
        Task<List<Point>> GetPointsByX(double x);
        Task<List<Point>> GetPointsByY(double y);
        Task<List<Point>> GetPointsByName(string name);
        Task<List<Point>> GetPointsByIstasyonNo(int istasyonNo);  // ✅ eklendi
        Task<Point> UpdatePoint(int id, double newX, double newY, string newName, int newIstasyonNo); // ✅ tutarlı
        Task<List<Point>> UpdatePointNameById(int id, string newName);
        Task<int> DeletePointById(int id);
        Task<Point> AddPoint(Point point);
    }
}