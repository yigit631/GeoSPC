﻿using MapApp2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MapApp2.Services
{
    public class TemperatureAnalysisService : ITemperatureAnalysisService
    {
        public async Task<XBarResult> GenerateXBarAsync(List<double> temperatures)
        {
            if (temperatures == null || temperatures.Count < 2)
                throw new ArgumentException("At least two temperature values are required for X̄ analysis.");

            var mean = temperatures.Average();
            var stdDev = Math.Sqrt(temperatures.Sum(t => Math.Pow(t - mean, 2)) / temperatures.Count);
            var ucl = mean + 3 * stdDev;
            var lcl = mean - 3 * stdDev;

            return await Task.FromResult(new XBarResult
            {
                Mean = mean,
                UCL = ucl,
                LCL = lcl,
                Count = temperatures.Count
            });
        }
    }
}