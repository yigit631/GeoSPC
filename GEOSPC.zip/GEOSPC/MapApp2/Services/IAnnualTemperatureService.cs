﻿using MapApp2.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MapApp2.Services
{
    public interface IAnnualTemperatureService
    {
        Task<AnnualTemperatureResponse> GetAnnualAveragesAsync(int pointId);
    }
}