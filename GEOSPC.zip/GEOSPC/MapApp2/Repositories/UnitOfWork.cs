﻿using MapApp2.Data;
using MapApp2.Entity;

namespace MapApp2.Repositories
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly AppDbContext _context;
        public IPointRepository Points { get; }
        public IRepository<TemporImport> TemporImports => _temporImportRepository ??= new Repository<TemporImport>(_context);
        private IRepository<TemporImport> _temporImportRepository;

        public UnitOfWork(AppDbContext context)
        {
            _context = context;
            Points = new PointRepository(_context);
        }

        public async Task<int> CompleteAsync()
        {
            return await _context.SaveChangesAsync();
        }

        public void Dispose()
        {
            _context.Dispose();
        }
    }
}