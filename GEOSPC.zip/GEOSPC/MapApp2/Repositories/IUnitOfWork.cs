﻿using MapApp2.Entity;
using System.Threading.Tasks;

namespace MapApp2.Repositories
{
    public interface IUnitOfWork
    {
        IPointRepository Points { get; }
        IRepository<TemporImport> TemporImports { get; }
        Task<int> CompleteAsync();
        void Dispose();
    }
}