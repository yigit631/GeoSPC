﻿using MapApp2.Data;
using MapApp2.Entity;
using Microsoft.EntityFrameworkCore;

namespace MapApp2.Repositories
{
    public class PointRepository : Repository<Point>, IPointRepository
    {
        public PointRepository(AppDbContext context) : base(context)
        {
        }

        // Point'e özgü ek metotlar buraya eklenebilir
    }
}