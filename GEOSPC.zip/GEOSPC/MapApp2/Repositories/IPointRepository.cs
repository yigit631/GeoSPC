﻿using MapApp2.Entity;

namespace MapApp2.Repositories
{
    public interface IPointRepository : IRepository<Point>
    {
        // Point'e özgü ek metotlar buraya eklenebilir
    }
}