﻿using MapApp2.Entity;
using MapApp2.Services;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MapApp2.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TemporImportController : ControllerBase
    {
        private readonly ITemporImportService _temporImportService;

        public TemporImportController(ITemporImportService temporImportService)
        {
            _temporImportService = temporImportService;
        }

        // GET: api/TemporImport
        [HttpGet]
        public async Task<ActionResult<List<TemporImport>>> GetAll()
        {
            var data = await _temporImportService.GetAllAsync();
            return Ok(data);
        }

        // GET: api/TemporImport/{pointId}/{year}
        [HttpGet("{pointId}/{year}")]
        public async Task<ActionResult<List<TemporImport>>> GetByPointIdAndYear(int pointId, int year)
        {
            var data = await _temporImportService.GetByPointIdAndYearAsync(pointId, year);
            return Ok(data);
        }

        // POST: api/TemporImport/match
        [HttpPost("match")]
        public async Task<ActionResult<int>> MatchToPoint()
        {
            var matchedCount = await _temporImportService.MatchToPointAsync();
            return Ok(new { updated = matchedCount });
        }

        // POST: api/TemporImport/bulk
        [HttpPost("bulk")]
        public async Task<ActionResult<int>> BulkInsert([FromBody] List<TemporImport> data)
        {
            var insertedCount = await _temporImportService.BulkInsertAsync(data);
            return Ok(new { inserted = insertedCount });
        }
    }
}