﻿using MapApp2.Models;
using MapApp2.Services;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace MapApp2.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TemperatureController : ControllerBase
    {
        private readonly IAnnualTemperatureService _annualService;

        public TemperatureController(IAnnualTemperatureService annualService)
        {
            _annualService = annualService;
        }

        // GET: api/temperature/annual/{pointId}
        [HttpGet("annual/{pointId}")]
        public async Task<ActionResult<AnnualTemperatureResponse>> GetAnnual(int pointId)
        {
            var result = await _annualService.GetAnnualAveragesAsync(pointId);
            return Ok(result);
        }
    }
}